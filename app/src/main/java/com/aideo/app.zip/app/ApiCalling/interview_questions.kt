package com.aideo.app.ApiCalling

class InterviewQuestions {


    /*

    ------ For Android -------

    Q.1 what is android ?
    Answer. Android is an open-source Linux-based operating system commonly used on mobile devices such as smartphones and tablets.
    It is a kernel-based system that gives developers the ability to develop and deploy simple and/or advanced applications.
    and kotlin is a official language of android according to google. android is developer by andy rubin.

    Android can be used to code for and Android mobile and tv os. The optimization is best suited for 2D mobile apps.
    The following features can be used to make the apps:-

    Geolocation
    Storage access
    Camera access
    Network
    Third-Party SDKs


    Q2. What are the advantages of Android?


     */
}