package com.aideo.app.Adapters

class SingleVideoAdapter {

}