package com.aideo.app

import com.aideo.app.ApiCalling.ContentData

public val videos = ArrayList<ContentData>()

class GlobleVideos {
}