package com.aideo.app

data class Audio(val name: String, val uri: String)