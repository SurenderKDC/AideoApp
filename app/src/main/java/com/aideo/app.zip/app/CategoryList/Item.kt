package com.aideo.app.CategoryList

data class Item(val imageUrl: String)