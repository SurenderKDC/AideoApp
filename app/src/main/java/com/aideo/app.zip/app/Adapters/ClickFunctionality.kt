package com.aideo.app.Adapters

interface ClickFunctionality {

    fun clickOnLeftSide()

    fun clickOnRightSide()
}